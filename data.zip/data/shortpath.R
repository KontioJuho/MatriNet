




tumor_shortest_paths_mats <-  vector(mode = "list", length = 20L)


for(i in 1:20){
  
  diag(P_list[[i]]) <- 0
  
  pathMat  <- centrality(P_list[[i]])$ShortestPathLengths + 1
  newmat <- pathMat
  for(k in 1:ncol(pathMat)){
    
    for(m in 1:nrow(pathMat)){
      
      if(pathMat[k,m] == Inf){
        
        newmat[k,m] <- 0
        
      }else{
        
        newmat[k,m] <- 1/pathMat[k,m]
        
      }
      
    }
    
  }
  
  tumor_shortest_paths_mats[[i]] <- newmat
  
}


names(tumor_shortest_paths_mats) <- names(P_list)

min_shortest_paths_mats <- lapply(tumor_shortest_paths_mats, function(x) x[,1:5])



colnames(min_shortest_paths_mats[[1]])


revlist <- vector(mode ="list", length(colnames(min_shortest_paths_mats[[1]])))
names(revlist) <- colnames(min_shortest_paths_mats[[1]])


list <- vector(mode = "list", length = 5L)
names(list) <- colnames(min_shortest_paths_mats[[1]])

for(nams in names(list)){
list[[nams]] <- lapply(min_shortest_paths_mats, function(x) x[,which(colnames(x) == nams)])
}

#This function generates the LX plot data format
local_shortPath <- lapply(list, function(center) {
  lapply(center, function(tumshort.mat) ((1-tumshort.mat)-0.5)*2)}

)

local_shortpath <- lapply(local_shortPath, function(x) do.call(rbind, x))

for(i in 1:5){
  
  local_shortpath[[i]] <- local_shortpath[[i]][,-i]
  
}








shortest_paths <- vector(mode = "list", length = 214L)
names(shortest_paths) <- toupper(colnames(P_list[[1]]))

